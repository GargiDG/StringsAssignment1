
public class Strings1Q4 {
	public static String reverseWords(String s) {
        String[] words = s.split(" ");
        StringBuilder result = new StringBuilder();

        for (String word : words) {
            StringBuilder reversedWord = new StringBuilder(word);
            reversedWord.reverse();
            result.append(reversedWord).append(" ");
        }

        // Remove the trailing whitespace
        if (result.length() > 0) {
            result.setLength(result.length() - 1);
        }

        return result.toString();
    }
	 public static void main(String[] args) {
	        String s = "Let's take LeetCode contest";
	        String reversed = reverseWords(s);
	        System.out.println(reversed);
	    }

}

